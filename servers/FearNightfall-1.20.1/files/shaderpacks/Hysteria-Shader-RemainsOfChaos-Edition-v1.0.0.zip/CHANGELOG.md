# 1.2.1
- Fixed rain effects not showing properly on Iris 1.7 (photon/507aa35)

# 1.2.0
- Dusk is now darker, and its ground fog was increased

# 1.1.0
- Fixed banding on blocks when using Performance or Best Performance presets
- Added Volumetric Quality slider, which reduces noise on fog
- Increased default Volumetric Quality to medium